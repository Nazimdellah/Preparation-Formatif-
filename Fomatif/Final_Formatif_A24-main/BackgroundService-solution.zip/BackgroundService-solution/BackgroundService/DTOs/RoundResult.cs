﻿namespace SuperChance.DTOs
{
    public class RoundResult
    {
        public IEnumerable<string>? Winners { get; set; }
        public int NbClicks { get; set; }
    }
}
