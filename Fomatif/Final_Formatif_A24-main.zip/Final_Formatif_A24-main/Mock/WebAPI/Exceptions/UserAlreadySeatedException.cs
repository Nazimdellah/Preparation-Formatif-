﻿using System;
namespace WebAPI.Exceptions
{
	public class UserAlreadySeatedException: Exception
    {
	}
}

