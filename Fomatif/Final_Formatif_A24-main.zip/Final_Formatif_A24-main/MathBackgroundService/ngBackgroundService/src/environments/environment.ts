export const environment = {
  production: true,
  apiUrl: "https://superclicker.azurewebsites.net/"
};
